import os
os.system('echo hello > ransuccessfully.txt')
print('done')
