echo running:
python3 test.py
